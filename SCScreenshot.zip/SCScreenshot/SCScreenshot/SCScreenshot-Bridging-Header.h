//
//  SCScreenshot-Bridging-Header.h
//  SCScreenshot
//
//  Created by Aevit on 15/9/16.
//  Copyright (c) 2015年 Aevit. All rights reserved.
//

#ifndef SCScreenshot_SCScreenshot_Bridging_Header_h
#define SCScreenshot_SCScreenshot_Bridging_Header_h

#import "SCImageNavigationController.h"
#import "SCImageBrowser.h"

#endif
