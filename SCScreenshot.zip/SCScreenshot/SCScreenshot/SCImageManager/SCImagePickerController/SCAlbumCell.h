//
//  SCAlbumCell.h
//  SCImageBrowser
//
//  Created by Aevit on 15/9/8.
//  Copyright (c) 2015年 Aevit. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SCAlbumCell : UITableViewCell

@end
