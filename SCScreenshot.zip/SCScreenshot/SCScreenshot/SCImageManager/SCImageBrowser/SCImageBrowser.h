//
//  SCImageBrowser.h
//  SCImagePickerControllerDemo
//
//  Created by Aevit on 15/9/15.
//  Copyright (c) 2015年 Aevit. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SCZoomingScrollView.h"

@interface SCImageBrowser : UIViewController

@property (nonatomic, strong) UIImage *image;

@end
