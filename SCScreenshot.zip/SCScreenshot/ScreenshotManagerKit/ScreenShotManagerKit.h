//
//  ScreenShotManagerKit.h
//  ScreenShotManagerKit
//
//  Created by Aevit on 15/8/31.
//  Copyright (c) 2015年 Aevit. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ScreenShotManagerKit.
FOUNDATION_EXPORT double ScreenShotManagerKitVersionNumber;

//! Project version string for ScreenShotManagerKit.
FOUNDATION_EXPORT const unsigned char ScreenShotManagerKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ScreenShotManagerKit/PublicHeader.h>


